#!/bin/bash -x
# This file is copyright of Prolifics 2011. All rights reserved. You are not permitted to copy, modify, or redistribute this file.
# See the readme.txt file for further terms and conditions.

sudo echo $1 | base64 -d